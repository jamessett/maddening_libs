function madStart(){
noun1 =document.getElementById("noun1").value;
noun2 =document.getElementById("noun2").value;
noun3 =document.getElementById("noun3").value;
adj1 =document.getElementById("adj1").value;
adj2 =document.getElementById("adj2").value;
adj3 =document.getElementById("adj3").value;
username =document.getElementById("username").value;

document.getElementById("madLib").innerHTML ="<p> Some people really hate " + noun1 + " I don't understand why, " + noun1 + " is so " + adj1 + " . Since it's so " + adj1 + " I really can't grasp why people hate it. Is it because it's also " + adj2 + " and " + adj3 + " ? In the end i'm honestly not that bright, my name is " + username + " after all. Maybe I should reconsider my liking of " + noun1 + " . That could also explain why I like " + noun2 + " and " + noun3 + " , since i'm so incompetent. </p> <br> <br> <p> please refresh to resubmit. </p>"
}